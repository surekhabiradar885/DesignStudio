import {
  Component,
  OnInit,
  ViewChildren,
  QueryList,
  ElementRef,
} from '@angular/core';
import {
  trigger,
  transition,
  query,
  style,
  animate,
  group,
  state,
} from '@angular/animations';
import { CarouselComponent } from '../carousel/carousel.component';
import { LargeCarouselComponent } from '../large-carousel/large-carousel.component';
const left = [
  query(':enter, :leave', style({ position: 'fixed', width: '200px' }), { optional: true }),
  group([
    query(':enter', [style({  transform: 'translateX(100%)' }), animate('.3s ease-out', style({ transform: 'translateX(0%)' }))], {
      optional: true,
    }),
    query(':leave', [
      style({ transform: 'translateX(0%)' }), 
      animate('.3s ease-out', style({ transform: 'translateX(100px)' }))],
       {
      optional: true,
    }),
  ]),
];

const right = [
  query(':enter, :leave', style({ position: 'absolute', width: '200px' }), { optional: true }),
  group([
    query(':enter', [style({ transform: 'translateX(0%)' }), animate('.3s', style({ opacity: 1 }))], {
      optional: true,
    }),
    query(':leave', [style({ transform: 'translateX(0%)' }), animate('.3s', style({ transform: 'translateX(100px)' }))], {
      optional: true,
    }),
  ]),
]; 

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.css'],
  
})
export class SliderComponent implements OnInit {
  @ViewChildren(CarouselComponent, { read: ElementRef })
  mySlides: QueryList<ElementRef>;

  actions = [
    'Mobile internet',
    'Home internet',
    'Get a device',
    'Add a phone-line',
    'Upgrade',
  ];

  sliderFlag: boolean = false;
  constructor() {}

  ngOnInit(): void {}

  arrayRotate(arr: string[], direction: string): string[] {
    if (direction == 'right') {
      arr.push(arr.shift());
    } else {
      arr.unshift(arr.pop());
    }
    return arr;
  }
  show_image(direction: string) {
    this.sliderFlag = true;
    this.actions = this.arrayRotate(this.actions, direction);
  }
}
