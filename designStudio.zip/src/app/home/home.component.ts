import {
  Component,
  OnInit,
  ViewChild,
  ViewChildren,
  QueryList,
  ElementRef,
  AfterViewInit,
} from '@angular/core';
import { TweenLite, TimelineMax, gsap } from 'gsap';
import { Draggable } from 'gsap/Draggable';
import { CarouselComponent } from '../carousel/carousel.component';
import { SliderComponent } from '../slider/slider.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  num: number[] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

  constructor() {}
  ngOnInit(): void {}
  /* @ViewChild('picker',{ static: true }) picker: ElementRef;
  @ViewChild('prev',{ static: true }) prev: ElementRef; */
  @ViewChildren(CarouselComponent) carousel: QueryList<CarouselComponent>
  

  /* proxy = document.createElement('div');
 
  cellWidth = 450;
  numCells:number;
  
  cellStep :number;
  wrapWidth:number;
  tween:any;
  baseTl:any;
  carouselArr:any[];
  animation:any;
  
  Draggable=gsap.registerPlugin(Draggable);
 */
  ngAfterViewInit() {
    /* console.log('picker ' + this.picker.nativeElement.innerHTML);
    console.log("carouselInstance  "+this.carousel.toArray().length);
   this.numCells =this.carousel.toArray().length;
   this.carouselArr=this.carousel.toArray();
   this.cellStep = 1 / this.numCells;
   this.wrapWidth = this.cellWidth * this.numCells;
   this.baseTl = new TimelineMax({ paused: true });
   this.tween = TweenLite.set(this.picker, {
    width: this.wrapWidth - this.cellWidth,
  }); 
  for (var i = 0; i < this.numCells; i++) {  
    this.initCell(this.carouselArr[i], i);
  }
   this.animation = new TimelineMax({ repeat: -1, paused: true })
  .add(this.baseTl.tweenFromTo(1, 2));
  

  var draggable = new Draggable(this.proxy, {  
    // allowContextMenu: true,  
    type: "x",
    trigger: this.carouselArr,
    throwProps: true,
    onDrag: this.updateProgress,
    onThrowUpdate: this.updateProgress,
    snap: { 
      x: this.snapX
    },
    onThrowComplete: function(){
      console.log("onThrowComplete");
      //TODO: animation that inject selected card title
    }
  }); */
  }
  counter(i: number): any {
    return new Array(i);
  }
   /* snapX(x) {
    return Math.round(x / this.cellWidth) * this.cellWidth;
  }
  
   updateProgress() {  
   //this.animation.progress(Draggable.type / this.wrapWidth);
  }
  
 
   initCell(element:any[], index):void {
  
    TweenLite.set(element, {
      width: this.cellWidth,
      scale: 0.6,
      //rotationX: rotationX,
      x: -this.cellWidth
    });
  }
 */  
 
}
