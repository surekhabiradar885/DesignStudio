import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-large-carousel',
  templateUrl: './large-carousel.component.html',
  styleUrls: ['./large-carousel.component.css']
})
export class LargeCarouselComponent implements OnInit {
  @Input() title;
  constructor() { }

  ngOnInit(): void {
  }

}
